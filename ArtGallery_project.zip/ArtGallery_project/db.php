<?php 
    $host_name = "localhost";
    $db_name = "art_gallery";
    $username = "root";
    $password = "";
    $conn = new mysqli($host_name, $username, $password, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
 ?>